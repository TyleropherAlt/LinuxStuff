echo Starting......
sleep 3
mogrify -quality $((1 + RANDOM % 50)) *.png
mogrify -quality $((1 + RANDOM % 50)) *.jpg
echo done
sleep 2
