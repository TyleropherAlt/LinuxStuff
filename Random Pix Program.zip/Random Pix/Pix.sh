echo Pix Started
echo Warning This Will Change the Quality of Photos in the Directory
echo Open The File Make.sh File to make the files in the directory a different and random quality.
sleep 4.5
